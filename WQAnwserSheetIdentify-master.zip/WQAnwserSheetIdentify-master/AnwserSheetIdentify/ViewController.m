//
//  ViewController.m
//  AnwserSheetIdentify
//
//  Created by JWTHiOS02 on 2018/4/18.
//  Copyright © 2018年 cuipengfei. All rights reserved.
//

#import "ViewController.h"
#import "OpenCVManager.h"
#import "CameraViewController.h"
#import "JBCroppableImageView.h"

extern uint64_t dispatch_benchmark(size_t count, void (^block)(void));

@interface ViewController ()<CameraDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@property(nonatomic, strong) CameraViewController *cameraViewvController;

@property (nonatomic, strong)  UIImageView *imgeView11;

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;

@property (nonatomic,strong)UIImageView *image;

@property (nonatomic,strong)UIImageView *image2;

@property (nonatomic,strong)UIScrollView *scroll;
@property (nonatomic,strong)UIButton *btn;

@property (nonatomic,strong)JBCroppableImageView  *JBCroppableImage;

@property (nonatomic,strong)UIButton *crop; //剪切

@property (nonatomic,strong)UIButton *reverseCrop; //还原

@property (nonatomic,strong)UIButton *sureSelect; //确认选择

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _scroll = [[UIScrollView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:_scroll];
    
    self.image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 500)];

    self.image.backgroundColor = [UIColor yellowColor];
    [_scroll addSubview:self.image];
    
    _btn =[[UIButton alloc]initWithFrame:CGRectMake(170, 550,100, 50)];
    [_btn setTitle:@"转换" forState:UIControlStateNormal];
    [_btn setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [_btn addTarget:self action:@selector(buttonUp:) forControlEvents:UIControlEventTouchUpInside];
    [_scroll addSubview:_btn];
    self.image2 =[[UIImageView alloc]initWithFrame:CGRectMake(10, 600, self.view.frame.size.width-20, 500)];
    self.image2.backgroundColor = [UIColor greenColor];
    [_scroll addSubview:self.image2];
    
    _JBCroppableImage = [[JBCroppableImageView alloc]initWithFrame:CGRectMake(0, 1100, self.view.frame.size.width, 500)];
    [_scroll addSubview:_JBCroppableImage];
    
    _crop =[[UIButton alloc]initWithFrame:CGRectMake(50, 1600,100, 50)];
    [_crop setTitle:@"剪切" forState:UIControlStateNormal];
    [_crop setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [_crop addTarget:self action:@selector(cropUp) forControlEvents:UIControlEventTouchUpInside];
    [_scroll addSubview:_crop];
    
    _reverseCrop =[[UIButton alloc]initWithFrame:CGRectMake(150, 1600,100, 50)];
    [_reverseCrop setTitle:@"还原" forState:UIControlStateNormal];
    [_reverseCrop setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [_reverseCrop addTarget:self action:@selector(reverseCropUp) forControlEvents:UIControlEventTouchUpInside];
    [_scroll addSubview:_reverseCrop];
    
    _sureSelect =[[UIButton alloc]initWithFrame:CGRectMake(220, 1600,100, 50)];
    [_sureSelect setTitle:@"确认" forState:UIControlStateNormal];
    [_sureSelect setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    [_sureSelect addTarget:self action:@selector(sureSelectUP) forControlEvents:UIControlEventTouchUpInside];
    [_scroll addSubview:_sureSelect];
    _scroll.contentSize = CGSizeMake(self.view.frame.size.width, 2000);
}

-(void)buttonUp:(id)sender {
    //初始化UIImagePickerController类
    UIImagePickerController * picker = [[UIImagePickerController alloc] init];
    //判断数据来源为相册
    picker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    //设置代理
    picker.delegate = self;
    //打开相册
    [self presentViewController:picker animated:YES completion:nil];
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    //获取图片
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    [self dismissViewControllerAnimated:YES completion:nil];
    _JBCroppableImage.image = image;
    
}

//剪切
-(void)cropUp{
    NSArray *arrayold =_JBCroppableImage.pointsView.getPoints;
    NSLog(@"old+++++++++++++++%@",arrayold);
    [_JBCroppableImage crop];
    NSArray *arraynew =_JBCroppableImage.pointsView.getPoints;
    NSLog(@"old+++++++++++++++%@",arraynew);
}
//还原
-(void)reverseCropUp{
    [_JBCroppableImage reverseCrop];
}
//确认
-(void)sureSelectUP{
    UIImage *image =[self.JBCroppableImage getCroppedImage];
    float w= image.size.width/_JBCroppableImage.frame.size.width ;
    float h= image.size.height/_JBCroppableImage.frame.size.height ;
    NSArray *arrayold =_JBCroppableImage.pointsView.getPoints;
    NSLog(@"old+++++++++++++++%@",arrayold);

//    self.JBCroppableImage.image =[ViewController imageToTransparent:[self.JBCroppableImage getCroppedImage]];
    self.image2.image =[OpenCVManager correctWithUIImage:[self.JBCroppableImage getCroppedImage] And:_JBCroppableImage.pointsView.getPoints And:w And:h];

    NSArray *arraynew =_JBCroppableImage.pointsView.getPoints;
    NSLog(@"old+++++++++++++++%@",arraynew);
    //    });
//    self.image.image = [OpenCVManager correctWithUIImage2:[ViewController imageToTransparent:[self.JBCroppableImage getCroppedImage]]];
//    uint64_t time = dispatch_benchmark(1, ^{
//        self.image2.image = [OpenCVManager correctWithUIImage:[self.JBCroppableImage getCroppedImage]];
//    });
//    self.image.image = [OpenCVManager correctWithUIImage2:[self.JBCroppableImage getCroppedImage]];
//    NSLog(@"耗时 ---> %llu ns",time);
}


-(void)qweqwe{
    self.cameraViewvController = [[CameraViewController alloc] init];
    self.cameraViewvController.delegate = self;
    //self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    [self presentViewController:self.cameraViewvController animated:YES completion:nil];
}
- (IBAction)convert:(id)sender {
    
    self.cameraViewvController = [[CameraViewController alloc] init];
    self.cameraViewvController.delegate = self;
    //self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    [self presentViewController:self.cameraViewvController animated:YES completion:nil];

}
////选取照片的回调
//- (void)CameraTakePhoto:(UIImage *)image
//{
//
//    uint64_t time = dispatch_benchmark(1, ^{
//        self.image2.image = [OpenCVManager correctWithUIImage:image];
//    });
//    self.image.image = [OpenCVManager correctWithUIImage2:image];
//    NSLog(@"耗时 ---> %llu ns",time);
//
//}


@end
