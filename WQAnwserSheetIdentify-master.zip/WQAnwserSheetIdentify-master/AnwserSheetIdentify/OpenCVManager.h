//
//  OpenCVManager.h
//  OpenCVDemo
//
//  Created by JWTHiOS02 on 2018/4/4.
//  Copyright © 2018年 JWTHiOS02. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OpenCVManager : NSObject

+ (UIImage *)correctWithUIImage:(UIImage *)image And:(NSArray *)array And:(float)W And:(float)H; // 图像纠偏

+ (UIImage *)correctWithUIImage2:(UIImage *)image;
@end
