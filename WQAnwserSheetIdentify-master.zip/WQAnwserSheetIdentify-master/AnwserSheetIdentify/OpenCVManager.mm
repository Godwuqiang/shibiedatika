//
//  OpenCVManager.m
//  OpenCVDemo
//
//  Created by JWTHiOS02 on 2018/4/4.
//  Copyright © 2018年 JWTHiOS02. All rights reserved.
//

#import "OpenCVManager.h"
#import "opencv2/opencv.hpp"
#import "UIImage+OpenCV.h"

#define H(X) ((HEIGHT) * ((X) / 667.0))    // 适配屏幕高度（以667为基准iphone6）
#define W(X) ((WIDTH) * ((X) / 375.0))     // 适配屏幕宽度（以375为基准iphone6）
#define WIDTH [[UIScreen mainScreen] bounds].size.width
#define HEIGHT (kDevice_Is_iPhoneX ? ([[UIScreen mainScreen] bounds].size.height-34): [[UIScreen mainScreen] bounds].size.height)
#define kDevice_Is_iPhoneX              ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO) //iPhone X 的适配

using namespace std;
using namespace cv;


@implementation OpenCVManager

+ (UIImage *)correctWithUIImage:(UIImage *)image And:(NSArray *)array And:(float)W And:(float)H{
    cv::Mat inputMat;
    cv::Mat outputMat;
    cv::Mat tmp;
    
    inputMat = [image cvMatImage];
    
    
    
    // 构造变换矩阵
    cv::Point2f src_vertices[4];
    CGPoint one = [[array objectAtIndex:3] CGPointValue];
    src_vertices[0] = cv::Point(one.x*W,one.y*H);
    CGPoint two = [[array objectAtIndex:2] CGPointValue];
    src_vertices[1] = cv::Point(two.x*W,two.y*H);
    CGPoint three = [[array objectAtIndex:1] CGPointValue];
    src_vertices[2] = cv::Point(three.x*W,three.y*H);
    CGPoint four = [[array objectAtIndex:0] CGPointValue];
    src_vertices[3] = cv::Point(four.x*W,four.y*H);
    
    cv::Point2f dst_vertices[4];
    float kuan = two.x*W-one.x*W;
    float gao  = two.y*H -four.y*H;
    dst_vertices[0] = cv::Point(0,gao);
    dst_vertices[1] = cv::Point(kuan,gao);
    dst_vertices[2] = cv::Point(kuan,0);
    dst_vertices[3] = cv::Point(0,0);
    cv::Mat transform = cv::getPerspectiveTransform(src_vertices,dst_vertices);
    cv::warpPerspective(inputMat, tmp, transform, cv::Size(kuan, gao));
    tmp.copyTo(inputMat);

    //
    // 转灰度图像
    cv::cvtColor(inputMat, tmp, CV_BGR2GRAY);
    outputMat = tmp;
    // 记录灰度值
    cv::Mat grayMat;
    tmp.copyTo(grayMat);
    
    // 滤波 去噪声
    cv::blur(outputMat, tmp, cv::Size(3,3));
    outputMat = tmp;
    
    // THRESH_BINARY：二值化
    
    cv::adaptiveThreshold(outputMat, tmp, 255, CV_ADAPTIVE_THRESH_MEAN_C, CV_THRESH_BINARY_INV, 225, 40);
    tmp.copyTo(grayMat);
    
    // 设置ROI, 使用容器记录ROI
    //margin_col 横 item 间距
    //margin_row 纵item 间距
    //leading距离左边
    //bottom 纵最后一列距离底部距离
    //trailing 横最后一类距离右边距离
    std::vector<cv::Rect> ROIRect;
    float leading = grayMat.cols*5.8/132, trailing =grayMat.cols*5.5/132, top =grayMat.rows*7.5/142.8, bottom =grayMat.rows*3.5/142.8, margin_col =grayMat.cols*6.3/132, margin_row = grayMat.rows*6.4/142.8,  row = 7, col = 4;
    float width = (grayMat.cols - leading - trailing - margin_col * (col - 1)) / col;
    float height = (grayMat.rows - top - bottom - margin_row * (row - 1)) / row;
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            // 此处 +0.7 为特殊校准，不应该有
            cv::Rect rect = cv::Rect(j * (width + margin_col) + leading, i * (height + margin_row) + top, width, height);
            ROIRect.push_back(rect);
//            cv::rectangle(grayMat, rect, cv::Scalar(255,0,0,1));
        }
    }
    
    //        return [UIImage imageWithCVMat:grayMat];
    // 遍历ROI，设置并记录每道题的ROI
    std::vector<cv::Rect> ROIItemRect;
    for (int i = 0; i < ROIRect.size(); i++) {
        cv::Rect rect = ROIRect[i];
        int margin_height = 0;
        //        height = (rect.height - margin_height * 4) / 5;
        float with =(rect.width ) / 5;
        for (int k = 0; k < 5; k++) {
            //            cv::Rect itemRect = cv::Rect(rect.x, rect.y + (height + margin_height) * k, rect.width, height);
            cv::Rect itemRect = cv::Rect(rect.x +(with+margin_height)*k, rect.y,width/5, height);
            ROIItemRect.push_back(itemRect);
//            cv::rectangle(grayMat, itemRect, cv::Scalar(255,0,0,1));
        }
    }
    
    // 二值化 灰度图
    cv::Mat binaryMat;
    grayMat.copyTo(binaryMat);
    //    cv::adaptiveThreshold(grayMat, binaryMat, 255, cv::ADAPTIVE_THRESH_MEAN_C, cv::THRESH_BINARY, 25, 10);
    //    cv::threshold(grayMat, binaryMat,100, 255, cv::THRESH_BINARY);
    //    return [UIImage imageWithCVMat:binaryMat];
    NSMutableArray *dataArray= [NSMutableArray array];
    long average = [UIImage yuZhiWithCVMat:binaryMat];
    int max =10;
    for (int i = 0; i < ROIItemRect.size(); i++) {  // 遍历每道题
        cv::Rect rect = ROIItemRect[i];
        // 分割选项
        cv::Mat rectMat =binaryMat(rect);
        
        // 分割选项
        NSMutableArray * array= [NSMutableArray array];
        float heigh =rect.height/4;
        long small = 0;
        int choose = 0;
        for (int k = 0; k < 4; k++) {
            //            cv::Rect itemRect = cv::Rect(rect.x + width * k, rect.y, width, rect.height);
            cv::Rect itemRect = cv::Rect(rect.x, rect.y + (heigh)* k, rect.width, heigh);
            cv::Mat roiMat = binaryMat(itemRect);   // 截取ROI
            long count = [UIImage yuZhiWithCVMat:roiMat];  // 统计色值
            cv::rectangle(binaryMat, itemRect, cv::Scalar(255,0,0,1));
            
            // 超过 平均阈值 算作有效答案
            if (count > average && count>max) {
                NSLog(@"%ld",count);
                if (small<count) {
                    small = count;
                    choose = k;
                }
                switch (k) {
                    case 0:
                    {
                        NSLog(@"第 %d 题：A",i + 1);
                        [array addObject:@"A"];
                    }
                        break;
                    case 1:
                    {
                        NSLog(@"第 %d 题：B",i + 1);
                        [array addObject:@"B"];
                    }
                        break;
                    case 2:
                    {
                        NSLog(@"第 %d 题：C",i + 1);
                        [array addObject:@"C"];
                    }
                        
                        break;
                    case 3:
                    {
                        NSLog(@"第 %d 题：D",i + 1);
                        [array addObject:@"D"];
                    }
                        
                        break;
                    case 4:
                    {
                        NSLog(@"第 %d 题：E",i + 1);
                        [array addObject:@"E"];
                    }
                        break;
                        
                    default:
                        break;
                }
                continue;
            }
        }
        if (array.count>1) {
            switch (choose) {
                case 0:
                {
                    [array insertObject:@"A" atIndex:0];
                }
                    break;
                case 1:
                {
                    [array insertObject:@"B" atIndex:0];
                }
                    break;
                case 2:
                {
                    [array insertObject:@"C" atIndex:0];
                }
                    
                    break;
                case 3:
                {
                    [array insertObject:@"D" atIndex:0];
                }
                    
                    break;
                case 4:
                {
                    [array insertObject:@"E" atIndex:0];
                }
                    break;
                    
                default:
                    break;
            }
            
        }
        array = [array valueForKeyPath:@"@distinctUnionOfObjects.self"];
        [dataArray addObject:array];
    }
    return [UIImage imageWithCVMat:binaryMat];
}

cv::Mat wqqwer(cv::Mat & import){
    cv::Mat threshold_output;
    std::vector<std::vector<cv::Point>> contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::Mat src_gray;
    cv::Mat frame;
    //自定义形态学元素结构
    cv::Mat element5(9, 9, CV_8U, cv::Scalar(1));//5*5正方形，8位uchar型，全1结构元素
    cv::Scalar color = cvScalar(0, 0, 255);
    cv::Mat closed;
    cv::Rect rect;
//    frame = cv::imread("./lunkuo.jpg");
    frame = import;
//    imshow("src", frame);
    cv::Mat image = frame.clone();
//    cvWaitKey(1000);
    cvtColor(frame, src_gray, cv::COLOR_BGR2GRAY);
    //使用Canny检测边缘
    Canny(src_gray, threshold_output, 80, 126, (static_cast<void>(3), 3));
    //高级形态学闭运算函数
    cv::morphologyEx(threshold_output, closed, cv::MORPH_CLOSE, element5);
//    imshow("canny", threshold_output);
//    imshow("erode", closed);
    // 寻找外轮廓轮廓
    findContours(closed, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE, cv::Point());
    std::cout << contours.size() << std::endl;
    for (int i = 0; i < contours.size(); i++)
    {
        
        for (int j = 0; j < contours[i].size(); j++)
        {
            
            std::cout << &contours[i][j] << std::endl;
            //遍历轮廓中每个像素点并且赋值颜色
            //frame.at<Vec3b>(contours[i][j].y, contours[i][j].x) = (0, 0, 255);
        }
        
    }
    //转换轮廓点到最大外矩形框
    rect = cv::boundingRect(contours[0]);
    rectangle(image,rect,color);
    //加矩形框后的图片
    return image;
    imshow("rect", image);
    cvWaitKey(0);
}


// 计算直线交点
cv::Point CrossPointWithLine(cv::Vec4i & line1, cv::Vec4i & line2) {
    
    int l1_1_x = line1[0];
    int l1_1_y = line1[1];
    int l1_2_x = line1[2];
    int l1_2_y = line1[3];
    
    float a = (l1_1_y - l1_2_y) / ((l1_1_x - l1_2_x) == 0 ? 1.0 :(l1_1_x - l1_2_x));
    float b = l1_1_y - l1_1_x * a;
    
    int l2_1_x = line2[0];
    int l2_1_y = line2[1];
    int l2_2_x = line2[2];
    int l2_2_y = line2[3];
    
    float c = (l2_1_y - l2_2_y) / ((l2_1_x - l2_2_x) == 0 ? 1.0 : (l2_1_x - l2_2_x));
    float d = l2_1_y - l2_1_x * c;
    
    float x = (d - b) / (a - c);
    float y = (a*d - b*c) / (a - c);
    
    return cv::Point(x,y);
}

+ (UIImage *)correctWithUIImage2:(UIImage *)image {
    cv::Mat inputMat;
    cv::Mat outputMat;
    cv::Mat tmp;
    
    inputMat = [image cvMatImage];
    cv::cvtColor(inputMat, tmp, CV_BGR2GRAY);
    outputMat = tmp;
        //确定腐蚀和膨胀核的大小
        cv::Mat element = getStructuringElement(cv::MORPH_RECT, cv::Size(1,1));
        //腐蚀操作
        erode(outputMat,tmp,element);
        //膨胀操作
        dilate(tmp,outputMat,element);
    // THRESH_BINARY：二值化
    cv::adaptiveThreshold(outputMat, tmp, 255, cv::ADAPTIVE_THRESH_MEAN_C, cv::THRESH_BINARY, 25, 10);
    cv::Mat grayMat;
    tmp.copyTo(grayMat);
//    return [UIImage imageWithCVMat:tmp];
//    // 压缩
//    cv::resize(inputMat, tmp, cv::Size(inputMat.rows , inputMat.cols));
//    outputMat = tmp;
//
//    // 记录压缩图像
//    cv::Mat resizeMat;
//    tmp.copyTo(resizeMat);
//
//    // 转灰度图像
//    cv::cvtColor(outputMat, tmp, CV_BGR2GRAY);
//    outputMat = tmp;
//
//    // 记录灰度值
//    cv::Mat grayMat;
//    tmp.copyTo(grayMat);
//
//    // 滤波 去噪声
//    cv::blur(outputMat, tmp, cv::Size(3,3));
//    outputMat = tmp;
//
//
//    // THRESH_BINARY：二值化
//    cv::adaptiveThreshold(outputMat, tmp, 255, cv::ADAPTIVE_THRESH_MEAN_C, cv::THRESH_BINARY_INV, 25, 10);
//    //    cv::threshold(outputMat, tmp, [UIImage yuZhiWithCVMat:outputMat], 255, cv::THRESH_BINARY_INV);
//    outputMat = tmp;
//
//    // 边缘检测
//    cv::Canny(outputMat, tmp, 0, 50);
//    outputMat = tmp;
//
//    //    //确定腐蚀和膨胀核的大小
//    //    cv::Mat element = getStructuringElement(cv::MORPH_RECT, cv::Size(3,3));
//    //    //腐蚀操作
//    //    erode(outputMat,tmp,element);
//    //    //膨胀操作
//    //    dilate(tmp,outputMat,element);
//
//    // 边角检测  填充边界内空白色值
//    std::vector<std::vector<cv::Point>> contours;
//    cv::findContours(outputMat, contours, CV_RETR_LIST, CV_CHAIN_APPROX_NONE);
//    for (int i = 0; i < contours.size(); i++) {
//        for (int j = 0; j < contours[i].size(); j++) {
//            // 根据点画圆
//            cv::Point point = cv::Point(contours[i][j].x, contours[i][j].y);
//            cv::circle(outputMat, point, 1, cv::Scalar(255,0,0,1), 2.5);
//        }
//    }
//    //    return [UIImage imageWithCVMat:outputMat];
//    // 直线检测
//    std::vector<cv::Vec4i> lines;
//    outputMat.copyTo(resizeMat);
//    cv::HoughLinesP(outputMat, lines, 1, CV_PI/180, resizeMat.rows / 4, resizeMat.rows / 2, 5);
//
//    cv::Vec4i filtLines[4];   // 过滤的线 [上，左，下，右]
//    int filtLineFlag[4] = {0};
//
//    cv::Point originPoint = cv::Point(resizeMat.rows / 2, resizeMat.cols / 2); // 原点
//
//    for (size_t i = 0; i < lines.size(); i++) {
//        cv::Vec4i line = lines[i];
//        cv::Point point_1 = cv::Point(line[0],line[1]);
//        cv::Point point_2 = cv::Point(line[2],line[3]);
//
//        // 过滤线
//        if (point_1.y > originPoint.y && point_2.y > originPoint.y && filtLineFlag[0] == 0) {
//            filtLines[0] = line;
//            filtLineFlag[0] = 1;
//            cv::line(resizeMat, point_1, point_2, cv::Scalar(255,0,0,1));
//        }
//
//        if (point_1.x < originPoint.x && point_2.x < originPoint.x && filtLineFlag[1] == 0) {
//            filtLines[1] = line;
//            filtLineFlag[1] = 1;
//            cv::line(resizeMat, point_1, point_2, cv::Scalar(255,0,0,1));
//        }
//
//        if (point_1.y < originPoint.y && point_2.y < originPoint.y && filtLineFlag[2] == 0) {
//            filtLines[2] = line;
//            filtLineFlag[2] = 1;
//            cv::line(resizeMat, point_1, point_2, cv::Scalar(255,0,0,1));
//        }
//
//        if (point_1.x > originPoint.x && point_2.x > originPoint.x && filtLineFlag[3] == 0) {
//            filtLines[3] = line;
//            filtLineFlag[3] = 1;
//            cv::line(resizeMat, point_1, point_2, cv::Scalar(255,0,0,1));
//        }
//        cv::line(resizeMat, point_1, point_2, cv::Scalar(255,0,0,1));
//    }
//
//    // 四个交点
//    std::vector<cv::Point> filtPoints; // 存放计算的焦点
//    filtPoints.push_back(CrossPointWithLine(filtLines[0], filtLines[1]));
//    filtPoints.push_back(CrossPointWithLine(filtLines[0], filtLines[3]));
//    filtPoints.push_back(CrossPointWithLine(filtLines[1], filtLines[2]));
//    filtPoints.push_back(CrossPointWithLine(filtLines[3], filtLines[2]));
//
//    for (int i = 0; i < filtPoints.size(); i++) {
//        cv::circle(resizeMat, filtPoints[i], 10, cv::Scalar(255,0,0,1));
//    }
//
//    // 构造变换矩阵
//    cv::Point2f src_vertices[4];
//    src_vertices[0] = filtPoints[0];
//    src_vertices[1] = filtPoints[1];
//    src_vertices[2] = filtPoints[2];
//    src_vertices[3] = filtPoints[3];
//
//    cv::Point2f dst_vertices[4];
//    dst_vertices[0] = cv::Point(0,resizeMat.cols);
//    dst_vertices[1] = cv::Point(resizeMat.rows,resizeMat.cols);
//    dst_vertices[2] = cv::Point(0, 0);
//    dst_vertices[3] = cv::Point(resizeMat.rows,0);
//
//    // 透视变换
//    cv::Mat transform = cv::getPerspectiveTransform(src_vertices,dst_vertices);
//    cv::warpPerspective(grayMat, tmp, transform, cv::Size(resizeMat.rows, resizeMat.cols));
//    grayMat = tmp;
    
    //    return [UIImage imageWithCVMat:grayMat];
    // 设置ROI, 使用容器记录ROI
    //margin_col 横 item 间距
    //margin_row 纵item 间距
    //leading距离左边
    //bottom 纵最后一列距离底部距离
    //trailing 横最后一类距离右边距离
    std::vector<cv::Rect> ROIRect;
    int leading = 19, trailing = 0, top = 30, bottom = 10, margin_col = 20, margin_row = 26, width = 0, height = 0, row = 5, col = 4;
    width = (grayMat.cols - leading - trailing - margin_col * (col - 1)) / col;
    height = (grayMat.rows - top - bottom - margin_row * (row - 1)) / row;
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            // 此处 +0.7 为特殊校准，不应该有
            cv::Rect rect = cv::Rect(j * (width + margin_col) + leading, i * (height + margin_row) + top, width, height);
            ROIRect.push_back(rect);
//            cv::rectangle(grayMat, rect, cv::Scalar(255,0,0,1));
        }
    }
    
    //        return [UIImage imageWithCVMat:grayMat];
    // 遍历ROI，设置并记录每道题的ROI
    std::vector<cv::Rect> ROIItemRect;
    for (int i = 0; i < ROIRect.size(); i++) {
        cv::Rect rect = ROIRect[i];
        int margin_height = 0;
        //        height = (rect.height - margin_height * 4) / 5;
        double with =width / 5;
        for (int k = 0; k < 5; k++) {
            //            cv::Rect itemRect = cv::Rect(rect.x, rect.y + (height + margin_height) * k, rect.width, height);
            cv::Rect itemRect = cv::Rect(rect.x +(with)*k, rect.y,with, rect.height);
            ROIItemRect.push_back(itemRect);
//            cv::rectangle(grayMat, itemRect, cv::Scalar(255,0,0,1));
        }
    }
    
    // 二值化 灰度图
    cv::Mat binaryMat;
    grayMat.copyTo(binaryMat);
//    cv::adaptiveThreshold(grayMat, binaryMat, 255, cv::ADAPTIVE_THRESH_MEAN_C, cv::THRESH_BINARY, 25, 10);
    //    cv::threshold(grayMat, binaryMat,100, 255, cv::THRESH_BINARY);
    //    return [UIImage imageWithCVMat:binaryMat];
    for (int i = 0; i < ROIItemRect.size(); i++) {  // 遍历每道题
        cv::Rect rect = ROIItemRect[i];
        // 分割选项
        double hei =height/4;
        for (int k = 0; k < 4; k++) {
            //            cv::Rect itemRect = cv::Rect(rect.x + width * k, rect.y, width, rect.height);
            cv::Rect itemRect = cv::Rect(rect.x, rect.y + hei* k, rect.width, hei);
            cv::Mat roiMat = binaryMat(itemRect);   // 截取ROI
            cv::rectangle(grayMat, itemRect, cv::Scalar(255,0,0,1));
            int count = 0;  // 统计色值
            for (int x = 0; x < roiMat.rows; x++) {
                for (int y = 0; y < roiMat.cols; y++) {
                    
                    if (roiMat.at<uchar>(x,y) == 0) {
                        count ++;
                    }
                }
            }
            
            // 超过 30% 算作有效答案
            if (count > roiMat.rows * roiMat.cols * 0.30) {
                switch (k) {
                    case 0:
                        NSLog(@"第 %d 题：A",i + 1);
                        break;
                    case 1:
                        NSLog(@"第 %d 题：B",i + 1);
                        break;
                    case 2:
                        NSLog(@"第 %d 题：C",i + 1);
                        break;
                    case 3:
                        NSLog(@"第 %d 题：D",i + 1);
                        break;
                    case 4:
                        NSLog(@"第 %d 题：E",i + 1);
                        break;
                        
                    default:
                        break;
                }
                continue;
            }
        }
    }
    return [UIImage imageWithCVMat:grayMat];
}

@end
